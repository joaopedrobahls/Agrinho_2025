let player;
let obstacles = [];
let lanes = 5;
let laneHeight;
let gameOver = false;
let score = 0;
let lastScoreUpdate = 0;
let scenario = 'country';
let scenarioChangeTime = 0;

function setup() {
  createCanvas(800, 400);
  laneHeight = height / lanes;
  player = new Tomato();
  createObstacles();
  textFont('Arial');
}

function draw() {
  drawBackground();
  drawRoad();
  updateObstacles();
  player.show();
  updateScore();
  checkScenarioChange();

  if (gameOver) {
    showGameOver();
  }
}

function drawBackground() {
  if (scenario === 'country') {
    background(120, 200, 120); // Verde campo
  } else {
    background(150); // Cinza cidade
  }

  fill(0, 0, 0, 100);
  rect(0, 0, width, height);
}

function drawRoad() {
  for (let i = 0; i < lanes; i++) {
    if (scenario === 'country') {
      fill(100, 200, 100, 150);
    } else {
      fill(100, 100, 100, 150);
    }
    rect(0, i * laneHeight, width, laneHeight);

    if (i > 0) {
      stroke(255, 255, 0, 200);
      line(0, i * laneHeight, width, i * laneHeight);
    }
  }
  noStroke();
}

function createObstacles() {
  obstacles = [];
  for (let i = 1; i < lanes; i++) { // faixa 0 livre
    let y = i * laneHeight + laneHeight / 2;
    let speed = random(2, 6);
    let direction = random([1, -1]);

    let type;
    if (scenario === 'country') {
      type = random(['tractor', 'animal', 'bike']);
    } else {
      type = random(['car', 'bus', 'taxi', 'motorcycle']);
    }

    obstacles.push(new Obstacle(y, speed * direction, type));
  }
}

function updateObstacles() {
  for (let lane of obstacles) {
    lane.update();
    lane.show();
    if (lane.checkCollision(player)) {
      gameOver = true;
    }
  }
}

function updateScore() {
  if (millis() - lastScoreUpdate > 1000 && !gameOver) {
    score++;
    lastScoreUpdate = millis();
  }

  fill(255);
  textSize(24);
  textAlign(LEFT, TOP);
  text(`Pontuação: ${score}`, 20, 20);
  text(`Cenário: ${scenario === 'country' ? 'Campo' : 'Cidade'}`, 20, 50);
}

function checkScenarioChange() {
  if (millis() - scenarioChangeTime > 30000 && !gameOver) {
    changeScenario();
  }
}

function changeScenario() {
  scenario = scenario === 'country' ? 'city' : 'country';
  scenarioChangeTime = millis();
  createObstacles();
  player.y = laneHeight / 2;
}

function showGameOver() {
  fill(255, 0, 0, 200);
  rect(width / 2 - 200, height / 2 - 60, 400, 120, 20);

  fill(255);
  textSize(36);
  textAlign(CENTER, CENTER);
  text("💥 Fim de Jogo!", width / 2, height / 2 - 20);

  textSize(24);
  text(`Pontuação final: ${score}`, width / 2, height / 2 + 20);

  textSize(18);
  text("Pressione R para reiniciar", width / 2, height / 2 + 50);
  noLoop();
}

function keyPressed() {
  if (!gameOver) {
    if (key === 'W' || key === 'w') {
      player.move(0, -laneHeight);
    } else if (key === 'S' || key === 's') {
      player.move(0, laneHeight);
    } else if (key === 'A' || key === 'a') {
      player.move(-40, 0);
    } else if (key === 'D' || key === 'd') {
      player.move(40, 0);
    } else if (key === 'C' || key === 'c') {
      changeScenario();
    }
  } else if (key === 'R' || key === 'r') {
    resetGame();
  }
}

function resetGame() {
  gameOver = false;
  score = 0;
  lastScoreUpdate = millis();
  scenario = 'country';
  scenarioChangeTime = millis();
  player = new Tomato();
  createObstacles();
  loop();
}

class Tomato {
  constructor() {
    this.x = width / 2;
    this.y = laneHeight / 2; // faixa 0
    this.size = 30;
  }

  show() {
    textSize(this.size);
    textAlign(CENTER, CENTER);
    text("🍅", this.x, this.y);
  }

  move(dx, dy) {
    this.x = constrain(this.x + dx, 20, width - 20);
    this.y = constrain(this.y + dy, laneHeight / 2, height - laneHeight / 2);
  }
}

class Obstacle {
  constructor(y, speed, type) {
    this.y = y;
    this.speed = speed;
    this.type = type;
    this.obstacles = [];
    this.createObstacles();
  }

  createObstacles() {
    for (let i = 0; i < 3; i++) {
      let x = random(width);
      let size, emoji;

      switch (this.type) {
        case 'tractor': emoji = "🚜"; size = 40; break;
        case 'animal': emoji = random(["🐄", "🐖", "🐑"]); size = 30; break;
        case 'bike': emoji = "🚲"; size = 30; break;
        case 'car': emoji = "🚗"; size = 35; break;
        case 'bus': emoji = "🚌"; size = 45; break;
        case 'taxi': emoji = "🚕"; size = 35; break;
        case 'motorcycle': emoji = "🏍️"; size = 30; break;
        default: emoji = "🚗"; size = 35;
      }

      this.obstacles.push({ x: x, size: size, emoji: emoji });
    }
  }

  update() {
    for (let obs of this.obstacles) {
      obs.x += this.speed;

      if (this.speed > 0 && obs.x > width + 50) {
        obs.x = -50;
        if (random() < 0.3) this.randomizeObstacle(obs);
      }
      if (this.speed < 0 && obs.x < -50) {
        obs.x = width + 50;
        if (random() < 0.3) this.randomizeObstacle(obs);
      }
    }
  }

  randomizeObstacle(obs) {
    if (scenario === 'country') {
      obs.emoji = random(["🚜", "🐄", "🐖", "🐑", "🚲"]);
    } else {
      obs.emoji = random(["🚗", "🚌", "🚕", "🏍️"]);
    }
  }

  show() {
    for (let obs of this.obstacles) {
      textSize(obs.size);
      textAlign(CENTER, CENTER);
      text(obs.emoji, obs.x, this.y);
    }
  }

  checkCollision(player) {
    for (let obs of this.obstacles) {
      let d = dist(obs.x, this.y, player.x, player.y);
      if (d < 25) return true;
    }
    return false;
  }
}
